#include <iostream> 
using namespace std; 
 
class Node 
{ 
 	public: 
 	 	int data;  	 	Node* next; 
 	 	Node(int data) 
 	 	{ 
 	 	 	this->data=data; 
 	 	 	this->next=NULL; 
 	 	} 
}; 
 
void RemoveDuplicate(Node* &head) 
{ 
 	Node* temp=head; 
 
 	while(temp!=NULL) 
 	{ 
 	 	int check=temp->data;  	 	Node* prev=temp; 
 	 	Node* current=temp->next; 
 	 	while(current!=NULL) 
 	 	{ 
 	 	 	if(check==current->data) 
 	 	 	{ 
 	 	 	 	prev->next=current->next; 
 	 	 	  	 	 	} 
 	 	 	else 
 	 	 	{ 	current=prev->next; 
 	 	 	 	prev=current; 
 	 	 	  	 	 	} 	current=current->next; 
 	 	 
 	 	} 
 	 
 	 temp=temp->next; 	 
 	} 
 
} 
void Display(Node* &head) 
{ 
 	Node* temp=head;  	while(temp!=NULL) 
 	{ 
 	 	cout<<temp->data<<" , ";  	 	temp=temp->next; 
 	} 
 	cout<<endl; 
} 
 
int main() 
{ 
 	Node* head=NULL;  	Node* n1=new Node(1);  	head=n1; 
 	Node* n2=new Node(2);  	n1->next=n2;  	Node* n3=new Node(2);  	n2->next=n3;  	Node* n4=new Node(3);  	n3->next=n4;  	Node* n5=new Node(1);  	n4->next=n5; 
 	cout<<"origional elements:"; 
 	Display(head); 
 	RemoveDuplicate(head); 
 	cout<<"After removal_elements :"; 
 	Display(head); 
} 

