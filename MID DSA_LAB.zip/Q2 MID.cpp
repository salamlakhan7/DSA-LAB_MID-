#include <iostream>
using namespace std;
class Node
{
public:
int data;
Node* next;
Node(int data)
{
this->data=data;
this->next=NULL;
}
};
void Enqueue(Node* &F,Node* &R)
{
int data;
cout<<"entre an element to insert:";
cin>>data;
Node* P=new Node(data);
if(R==NULL && F==NULL)
{
R=P;
F=P;
}
else
{
R->next=P;
R=P;
}
}
void Dequeue(Node* &F,Node* &R)
{
if(R==NULL && F==NULL)
{
cout<<"Linked list is Empty.No Element to Delete";
}
else
{
 if(R==F)
 {
 R==NULL;
F==NULL;
 }
 else
 {
 F=F->next;
 }
 cout<<"Element fron Front is Deleted\n";
}
}
Display(Node* &F)
{
Node* temp=F;
if(temp==NULL)
{
cout<<"Linked List is Empty\n";
}
else
{
while(temp!=NULL)
{
cout<<temp->data<<" , ";
temp=temp->next;
}
cout<<endl;
}
}
int main()
{
Node* F=NULL;
 Node* R=NULL;
 Enqueue(F,R);
 Display(F);
 Enqueue(F,R);
 Display(F);
 Enqueue(F,R);
 Display(F);
 Enqueue(F,R);
 Display(F);

 Dequeue(F,R);
 Display(F);
 Dequeue(F,R);
 Display(F);
 Dequeue(F,R);
 Display(F);
Dequeue(F,R);
Display(F);
}
